The way to run this program

1. UnZip the folder
2. Make sure you have Python installed on your system
3. Open up your favorite terminal application
4. Navigate to this folder .../makeAMovieWebsite
5. run entertainment_center.py with python (OSX command is python entertainment_center.py)
6. Enjoy the trailers from some of my favorite movies